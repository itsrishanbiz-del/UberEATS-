# 🛵 UberEats KM Meter — Setup Guide

## What this app does
- Watches UberEats in the background
- When an order popup appears → **automatically reads** the fare (LKR) and distance (km)
- Shows a **floating widget** on top of UberEats with:
  - LKR per km rate
  - ✅ ACCEPT / ⚠️ MAYBE / ❌ SKIP verdict

---

## STEP 1 — Create a GitHub account
1. Open browser on your phone → go to **github.com**
2. Tap **Sign up** → create a free account

---

## STEP 2 — Create a new repository
1. After login, tap the **+** button (top right)
2. Tap **New repository**
3. Name it: `ubereats-km-meter`
4. Make it **Public**
5. Tap **Create repository**

---

## STEP 3 — Upload all files
Upload these files keeping the exact folder structure:

```
.github/workflows/build.yml
app/build.gradle
app/src/main/AndroidManifest.xml
app/src/main/java/com/ubereats/kmmeter/MainActivity.java
app/src/main/java/com/ubereats/kmmeter/UberEatsAccessibilityService.java
app/src/main/java/com/ubereats/kmmeter/FloatingWidgetService.java
app/src/main/res/layout/activity_main.xml
app/src/main/res/layout/widget_layout.xml
app/src/main/res/drawable/bg_good.xml
app/src/main/res/drawable/bg_okay.xml
app/src/main/res/drawable/bg_bad.xml
app/src/main/res/values/strings.xml
app/src/main/res/values/styles.xml
app/src/main/res/xml/accessibility_service_config.xml
build.gradle
settings.gradle
gradlew
gradle/wrapper/gradle-wrapper.properties
```

To upload on mobile:
- In your repo, tap **Add file → Upload files**
- Upload each file one by one (or zip them all and upload)

---

## STEP 4 — GitHub builds the APK automatically
1. Go to your repo → tap **Actions** tab
2. You'll see "Build APK" running (takes 3–5 minutes)
3. When it shows ✅ green → tap it
4. Scroll down to **Artifacts** → tap **UberEats-KM-Meter**
5. Download the zip → extract → install `app-debug.apk`

---

## STEP 5 — Install on your phone
1. In phone Settings → enable **Install from unknown sources**
2. Open the downloaded APK → tap Install
3. Open **UberEats KM Meter** app
4. Tap both permission buttons and grant them

---

## STEP 6 — How to use
- Open UberEats and go online as a driver
- When an order popup appears → widget appears automatically
- **Green border** = ACCEPT (LKR 45+/km)
- **Yellow border** = MAYBE (LKR 30–44/km)
- **Red border** = SKIP (under LKR 30/km)
- Drag the widget anywhere on screen
- Tap ✕ to hide it until next order

---

## Rate thresholds (can be adjusted)
Edit `FloatingWidgetService.java` line with `perKm >= 45` to change the ACCEPT threshold.
