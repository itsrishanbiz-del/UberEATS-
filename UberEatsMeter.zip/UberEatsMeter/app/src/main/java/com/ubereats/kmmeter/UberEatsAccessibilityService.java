package com.ubereats.kmmeter;

import android.accessibilityservice.AccessibilityService;
import android.content.Intent;
import android.view.accessibility.AccessibilityEvent;
import android.view.accessibility.AccessibilityNodeInfo;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class UberEatsAccessibilityService extends AccessibilityService {

    // Patterns to match UberEats order popup text
    // e.g. "LKR926.07" or "LKR 926.07"
    private static final Pattern FARE_PATTERN =
            Pattern.compile("LKR\\s?([\\d,]+\\.?\\d*)");

    // e.g. "24.3 km" or "(24.3 km)"
    private static final Pattern KM_PATTERN =
            Pattern.compile("\\(?([\\d.]+)\\s*km\\)?");

    private float lastFare = 0;
    private float lastKm   = 0;

    @Override
    public void onAccessibilityEvent(AccessibilityEvent event) {
        if (event == null) return;

        // Only scan when UberEats screen changes
        AccessibilityNodeInfo root = getRootInActiveWindow();
        if (root == null) return;

        String screenText = getAllText(root);
        root.recycle();

        // Must contain "Delivery" and "Confirm" to be an order popup
        if (!screenText.contains("Confirm") || !screenText.contains("km")) return;

        float fare = extractFare(screenText);
        float km   = extractKm(screenText);

        if (fare > 0 && km > 0 && (fare != lastFare || km != lastKm)) {
            lastFare = fare;
            lastKm   = km;
            showWidget(fare, km);
        }
    }

    private float extractFare(String text) {
        Matcher m = FARE_PATTERN.matcher(text);
        if (m.find()) {
            try {
                return Float.parseFloat(m.group(1).replace(",", ""));
            } catch (Exception ignored) {}
        }
        return 0;
    }

    private float extractKm(String text) {
        Matcher m = KM_PATTERN.matcher(text);
        if (m.find()) {
            try {
                return Float.parseFloat(m.group(1));
            } catch (Exception ignored) {}
        }
        return 0;
    }

    // Recursively collect all text from the screen
    private String getAllText(AccessibilityNodeInfo node) {
        if (node == null) return "";
        StringBuilder sb = new StringBuilder();
        if (node.getText() != null) sb.append(node.getText()).append(" ");
        for (int i = 0; i < node.getChildCount(); i++) {
            AccessibilityNodeInfo child = node.getChild(i);
            sb.append(getAllText(child));
            if (child != null) child.recycle();
        }
        return sb.toString();
    }

    private void showWidget(float fare, float km) {
        Intent intent = new Intent(this, FloatingWidgetService.class);
        intent.putExtra("fare", fare);
        intent.putExtra("km", km);
        startService(intent);
    }

    @Override
    public void onInterrupt() {}
}
