package com.ubereats.kmmeter;

import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.Service;
import android.content.Intent;
import android.graphics.Color;
import android.graphics.PixelFormat;
import android.os.Build;
import android.os.IBinder;
import android.view.Gravity;
import android.view.LayoutInflater;
import android.view.MotionEvent;
import android.view.View;
import android.view.WindowManager;
import android.widget.TextView;

public class FloatingWidgetService extends Service {

    private WindowManager windowManager;
    private View floatView;
    private WindowManager.LayoutParams params;

    private int initialX, initialY;
    private float initialTouchX, initialTouchY;

    private static final String CHANNEL_ID = "km_meter_channel";

    @Override
    public void onCreate() {
        super.onCreate();
        createNotificationChannel();
        startForeground(1, buildNotification());

        windowManager = (WindowManager) getSystemService(WINDOW_SERVICE);
        floatView = LayoutInflater.from(this).inflate(R.layout.widget_layout, null);

        int layoutFlag = Build.VERSION.SDK_INT >= Build.VERSION_CODES.O
                ? WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY
                : WindowManager.LayoutParams.TYPE_PHONE;

        params = new WindowManager.LayoutParams(
                WindowManager.LayoutParams.WRAP_CONTENT,
                WindowManager.LayoutParams.WRAP_CONTENT,
                layoutFlag,
                WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE,
                PixelFormat.TRANSLUCENT
        );
        params.gravity = Gravity.TOP | Gravity.START;
        params.x = 20;
        params.y = 200;

        windowManager.addView(floatView, params);
        setupDrag();
        setupClose();
    }

    @Override
    public int onStartCommand(Intent intent, int flags, int startId) {
        if (intent != null) {
            float fare = intent.getFloatExtra("fare", 0);
            float km   = intent.getFloatExtra("km", 0);
            if (fare > 0 && km > 0) updateWidget(fare, km);
        }
        return START_STICKY;
    }

    private void updateWidget(float fare, float km) {
        float perKm = fare / km;

        TextView tvPerKm  = floatView.findViewById(R.id.tvPerKm);
        TextView tvDetail = floatView.findViewById(R.id.tvDetail);
        TextView tvVerdict= floatView.findViewById(R.id.tvVerdict);
        View     card     = floatView.findViewById(R.id.widgetCard);

        tvPerKm.setText(String.format("%.1f", perKm));
        tvDetail.setText(String.format("LKR %.0f ÷ %.1f km", fare, km));

        if (perKm >= 45) {
            tvVerdict.setText("✅ ACCEPT");
            tvVerdict.setTextColor(Color.parseColor("#00c853"));
            tvPerKm.setTextColor(Color.parseColor("#00c853"));
            card.setBackgroundResource(R.drawable.bg_good);
        } else if (perKm >= 30) {
            tvVerdict.setText("⚠️ MAYBE");
            tvVerdict.setTextColor(Color.parseColor("#ffab00"));
            tvPerKm.setTextColor(Color.parseColor("#ffab00"));
            card.setBackgroundResource(R.drawable.bg_okay);
        } else {
            tvVerdict.setText("❌ SKIP");
            tvVerdict.setTextColor(Color.parseColor("#ff1744"));
            tvPerKm.setTextColor(Color.parseColor("#ff1744"));
            card.setBackgroundResource(R.drawable.bg_bad);
        }

        floatView.setVisibility(View.VISIBLE);
    }

    private void setupDrag() {
        floatView.setOnTouchListener((v, event) -> {
            switch (event.getAction()) {
                case MotionEvent.ACTION_DOWN:
                    initialX = params.x;
                    initialY = params.y;
                    initialTouchX = event.getRawX();
                    initialTouchY = event.getRawY();
                    return true;
                case MotionEvent.ACTION_MOVE:
                    params.x = initialX + (int)(event.getRawX() - initialTouchX);
                    params.y = initialY + (int)(event.getRawY() - initialTouchY);
                    windowManager.updateViewLayout(floatView, params);
                    return true;
            }
            return false;
        });
    }

    private void setupClose() {
        floatView.findViewById(R.id.btnClose).setOnClickListener(v ->
                floatView.setVisibility(View.GONE));
    }

    private void createNotificationChannel() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            NotificationChannel channel = new NotificationChannel(
                    CHANNEL_ID, "KM Meter", NotificationManager.IMPORTANCE_LOW);
            getSystemService(NotificationManager.class).createNotificationChannel(channel);
        }
    }

    private Notification buildNotification() {
        return new Notification.Builder(this, CHANNEL_ID)
                .setContentTitle("UberEats KM Meter Active")
                .setContentText("Watching for orders...")
                .setSmallIcon(android.R.drawable.ic_menu_mapmode)
                .build();
    }

    @Override
    public void onDestroy() {
        super.onDestroy();
        if (floatView != null) windowManager.removeView(floatView);
    }

    @Override
    public IBinder onBind(Intent intent) { return null; }
}
