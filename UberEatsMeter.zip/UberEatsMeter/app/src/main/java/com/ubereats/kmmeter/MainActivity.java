package com.ubereats.kmmeter;

import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.provider.Settings;
import android.widget.Button;
import android.widget.TextView;
import androidx.appcompat.app.AppCompatActivity;

public class MainActivity extends AppCompatActivity {

    Button btnOverlay, btnAccessibility;
    TextView tvStatus;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        btnOverlay       = findViewById(R.id.btnOverlay);
        btnAccessibility = findViewById(R.id.btnAccessibility);
        tvStatus         = findViewById(R.id.tvStatus);

        btnOverlay.setOnClickListener(v -> {
            Intent intent = new Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION,
                    Uri.parse("package:" + getPackageName()));
            startActivity(intent);
        });

        btnAccessibility.setOnClickListener(v -> {
            Intent intent = new Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS);
            startActivity(intent);
        });
    }

    @Override
    protected void onResume() {
        super.onResume();
        updateStatus();
    }

    void updateStatus() {
        boolean overlay      = Settings.canDrawOverlays(this);
        boolean accessibility = isAccessibilityEnabled();

        String status = "";
        if (!overlay)       status += "❌ Overlay permission needed — tap button 1\n\n";
        else                status += "✅ Overlay permission granted\n\n";

        if (!accessibility) status += "❌ Accessibility permission needed — tap button 2\n   Find 'UberEats KM Meter' and enable it";
        else                status += "✅ Accessibility permission granted\n\n🟢 APP IS ACTIVE!\nOpen UberEats — widget appears automatically when an order pops up.";

        tvStatus.setText(status);

        btnOverlay.setEnabled(!overlay);
        btnOverlay.setAlpha(overlay ? 0.4f : 1.0f);
        btnAccessibility.setEnabled(!accessibility);
        btnAccessibility.setAlpha(accessibility ? 0.4f : 1.0f);
    }

    boolean isAccessibilityEnabled() {
        String service = getPackageName() + "/" + UberEatsAccessibilityService.class.getCanonicalName();
        try {
            int enabled = Settings.Secure.getInt(getContentResolver(),
                    Settings.Secure.ACCESSIBILITY_ENABLED);
            if (enabled == 1) {
                String services = Settings.Secure.getString(getContentResolver(),
                        Settings.Secure.ENABLED_ACCESSIBILITY_SERVICES);
                if (services != null) {
                    return services.toLowerCase().contains(service.toLowerCase());
                }
            }
        } catch (Exception ignored) {}
        return false;
    }
}
